void f  ()//prototipo della funzione  è semplicemente il nome che da il segnificato alla funzione

tipo f1 ()
tipo f2 (tipo)
tipo f3 (tipo,tipo)

void //tip generico//procedura, una funzione che non restituisce nulla
la funzione restituisce sempre un valore associato al tipo[],int din

void f4(tipo &)passaggio per riferimento
void f5(int *) associato ad una stringa,+ PUNTATORE
int f6(int & a) // int passa per riferimento ad a
f7(int a[]),int din;
ripasso delle  funzioni modalità per passaggio e riferimento