
#include <iostream>  // differenza tra richiesta pubblico e privato, data un interfaccia dell'oggetto.
class A {
             public: int a;
             private: int b;
    
};
using namespace std;

int main()
{
    A a;
    //a.a=5; 
    a.b=7;
    
    
    

    return 0;
}
