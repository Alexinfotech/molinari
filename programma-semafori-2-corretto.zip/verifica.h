#include<iostream>
#include<stdlib.h>
#include<stdio.h>
#include<time.h>
using namespace std;
class verifica{
public:
    verifica();
    void ins_dim(); 
    void stampa();
   // void disp();
   // void stampa_disp();
   
    
  
private:
    
    int dim;
    float disp;
    int i;
    int* v;
    //vettore[];
    
    
};