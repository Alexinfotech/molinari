/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
	int N,n;
    int a=15;
    int b=88;
    int c=37;
    int d=5;
    int e=29;
    int f=59;
    int jolly=24;
    int super=72;
    cout<<"\nISERISCI I NUMERI DEL SISTEMA ENALOTTO IN ORDINE DI USCITA\n";
    cout<<"\n\tPRIMO NUMERO -->  ";
	cin>>n;
	if(n==a) 
	{
    cout<<"PRIMO NUMERO OK\n";
    cout<<"\n\tSECONDO NUMERO -->  ";
        cin>>n;
		    if( n==b )
		    {
		    cout<<"SECONDO NUEMRO OK\n"; 
		    cout<<"\n\tTERZO NUMERO -->  ";
		        cin>>n;
		            if(n==c)
		            {
		            cout<<"TERZO NUMERO OK\n";
		            cout<<"\n\tQUARTO NUMERO -->  ";
		                cin>>n;
		                    if(n==d)
		                    {
		                    cout<<"QUARTO NUEMRO OK\n";
		                    cout<<"\n\tQUINTO NUMERO -->  ";
		                        cin>>n;
		                            if(n==e)
		                            {
		                            cout<<"QUINTO NUMERO OK\n"; 
		                            cout<<"\n\tSESTO NUMERO -->  ";
		                                cin>>n;
		                                    if(n==f)
		                                    {
		                                    cout<<"SESTO NUEMRO OK\n\\n";
		                                    
		                                    cout<<"\t     @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n";
		                                    cout<<"\t  @@@ @@@@@@@ @@@@@@@ @@@@@@@@ @@@@@@@ @@@@@@@ @@@@@@@ @@@@@@@ \n";
		                                    cout<<"\t@@@@@  @@@@@  @@@@@  @@@@@  @@@@@  @@@@@  @@@@@  @@@@@  @@@@@  @\n";
		                                    cout<<"\t@@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @\n";
		                                    cout<<"\t@ # @ # @ # @ # @ # @ # @ # @ # @ # @ # @ # @ # @ # @ # @ # @ #@\n";
		                                    cout<<"\t@  #  @  #  @  #  @  #  @  #  @  #  @  #  @  #  @  #  @  #  @  #\n";
		                                    cout<<"\t#  #  #                                                  #  #  #\n";
		                                    cout<<"\t                 COMPLIMENTI SEI MILIARDARIO!!!                 \n";
		                                    cout<<"\t#  #  #                                                  #  #  #\n";
		                                    cout<<"\t@  #  @  #  @  #  @  #  @  #  @  #  @  #  @  #  @  #  @  #  @  #\n";
		                                    cout<<"\t@ # @ # @ # @ # @ # @ # @ # @ # @ # @ # @ # @ # @ # @ # @ # @ #@\n";
		                                    cout<<"\t@@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @\n";
		                                    cout<<"\t@@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @@ @\n";
		                                    cout<<"\t@@@@@  @@@@@  @@@@@  @@@@@  @@@@@  @@@@@  @@@@@  @@@@@  @@@@@  @|n";
		                                    cout<<"\t  @@@ @@@@@@@ @@@@@@@ @@@@@@@@ @@@@@@@ @@@@@@@ @@@@@@@ @@@@@@@ \n";
		                                    cout<<"\t     @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n";
		                                   
		                                    } 
		                                    else
    {
        cout<<"MI SPAICE NON HAI FATTO 6\n";
        cout<<"PROVA CON IL NUMERO JOLLY\n";
        cout<<"\n\t\tINSERISCI IL NUMERO JOLLY--> ";
        cin>>n;
         if(n==jolly)
		 {
		     
		 cout<<"\tHAI PRESO I NUMERO JOLLY\n\n\t\tCOMPLIMENTI!!!"; 
		 return 0;
		 }
		 else
		 {
		 cout<<"\nMI SPAICE NON HAI PRESO IL NUMERO JOLLY\n";    
		 cout<<"\nHAI L'ULTIMA POSSIBILITA'\nPROVA CON IL NUMERO SUPER STAR\n";
		 }
		 cout<<"\n\t\tINSERISCI IL NUMERO STAR--> ";
		 cin>>n;
		 if(n==super){
		   cout<<"\tHAI PRESO I NUMERO super star\n\n\t\tCOMPLIMENTI!!!";   
		 }
		 else
		 {
		     cout<<"\nSEI PROPRIO SFIGATO!!\n\n";
		     cout<<"\t\t@  @  @  @  @  @\n";
		     cout<<"\t\t ||    ||    ||\n";
		     cout<<"\t\t====  ====  ====\n";
		 
      
    
    }
    }
                                    }else
    {
        cout<<"MI SPAICE NON HAI FATTO 6\n";
        cout<<"PROVA CON IL NUMERO JOLLY\n";
        cout<<"\n\t\tINSERISCI IL NUMERO JOLLY--> ";
        cin>>n;
         if(n==jolly)
		 {
		     
		 cout<<"\tHAI PRESO I NUMERO JOLLY\n\n\t\tCOMPLIMENTI!!!"; 
		 return 0;
		 }
		 else
		 {
		 cout<<"\nMI SPAICE NON HAI PRESO IL NUMERO JOLLY\n";    
		 cout<<"\nHAI L'ULTIMA POSSIBILITA'\nPROVA CON IL NUMERO SUPER STAR\n";
		 }
		 cout<<"\n\t\tINSERISCI IL NUMERO STAR--> ";
		 cin>>n;
		 if(n==super){
		   cout<<"\tHAI PRESO I NUMERO super star\n\n\t\tCOMPLIMENTI!!!";   
		 }
		 else
		 {
		     cout<<"\nSEI PROPRIO SFIGATO!!\n\n";
		     cout<<"\t\t@  @  @  @  @  @\n";
		     cout<<"\t\t ||    ||    ||\n";
		     cout<<"\t\t====  ====  ====\n";
		 
      
    
    }
    }
                            }else
    {
        cout<<"MI SPAICE NON HAI FATTO 6\n";
        cout<<"PROVA CON IL NUMERO JOLLY\n";
        cout<<"\n\t\tINSERISCI IL NUMERO JOLLY--> ";
        cin>>n;
         if(n==jolly)
		 {
		     
		 cout<<"\tHAI PRESO I NUMERO JOLLY\n\n\t\tCOMPLIMENTI!!!"; 
		 return 0;
		 }
		 else
		 {
		 cout<<"\nMI SPAICE NON HAI PRESO IL NUMERO JOLLY\n";    
		 cout<<"\nHAI L'ULTIMA POSSIBILITA'\nPROVA CON IL NUMERO SUPER STAR\n";
		 }
		 cout<<"\n\t\tINSERISCI IL NUMERO STAR--> ";
		 cin>>n;
		 if(n==super){
		   cout<<"\tHAI PRESO I NUMERO super star\n\n\t\tCOMPLIMENTI!!!";   
		 }
		 else
		 {
		     cout<<"\nSEI PROPRIO SFIGATO!!\n\n";
		     cout<<"\t\t@  @  @  @  @  @\n";
		     cout<<"\t\t ||    ||    ||\n";
		     cout<<"\t\t====  ====  ====\n";
		 
      
    
    }
    }
                    }else
    {
        cout<<"MI SPAICE NON HAI FATTO 6\n";
        cout<<"PROVA CON IL NUMERO JOLLY\n";
        cout<<"\n\t\tINSERISCI IL NUMERO JOLLY--> ";
        cin>>n;
         if(n==jolly)
		 {
		     
		 cout<<"\tHAI PRESO I NUMERO JOLLY\n\n\t\tCOMPLIMENTI!!!"; 
		 return 0;
		 }
		 else
		 {
		 cout<<"\nMI SPAICE NON HAI PRESO IL NUMERO JOLLY\n";    
		 cout<<"\nHAI L'ULTIMA POSSIBILITA'\nPROVA CON IL NUMERO SUPER STAR\n";
		 }
		 cout<<"\n\t\tINSERISCI IL NUMERO STAR--> ";
		 cin>>n;
		 if(n==super){
		   cout<<"\tHAI PRESO I NUMERO super star\n\n\t\tCOMPLIMENTI!!!";   
		 }
		 else
		 {
		     cout<<"\nSEI PROPRIO SFIGATO!!\n\n";
		     cout<<"\t\t@  @  @  @  @  @\n";
		     cout<<"\t\t ||    ||    ||\n";
		     cout<<"\t\t====  ====  ====\n";
		 
      
    
    }
    }
            }else
    {
        cout<<"MI SPAICE NON HAI FATTO 6\n";
        cout<<"PROVA CON IL NUMERO JOLLY\n";
        cout<<"\n\t\tINSERISCI IL NUMERO JOLLY--> ";
        cin>>n;
         if(n==jolly)
		 {
		     
		 cout<<"\tHAI PRESO I NUMERO JOLLY\n\n\t\tCOMPLIMENTI!!!"; 
		 return 0;
		 }
		 else
		 {
		 cout<<"\nMI SPAICE NON HAI PRESO IL NUMERO JOLLY\n";    
		 cout<<"\nHAI L'ULTIMA POSSIBILITA'\nPROVA CON IL NUMERO SUPER STAR\n";
		 }
		 cout<<"\n\t\tINSERISCI IL NUMERO STAR--> ";
		 cin>>n;
		 if(n==super){
		   cout<<"\tHAI PRESO I NUMERO super star\n\n\t\tCOMPLIMENTI!!!";   
		 }
		 else
		 {
		     cout<<"\nSEI PROPRIO SFIGATO!!\n\n";
		     cout<<"\t\t@  @  @  @  @  @\n";
		     cout<<"\t\t ||    ||    ||\n";
		     cout<<"\t\t====  ====  ====\n";
		 
      
    
    }
    }
    }
    else
    {
        cout<<"MI SPAICE NON HAI FATTO 6\n";
        cout<<"PROVA CON IL NUMERO JOLLY\n";
        cout<<"\n\t\tINSERISCI IL NUMERO JOLLY--> ";
        cin>>n;
         if(n==jolly)
		 {
		     
		 cout<<"\tHAI PRESO I NUMERO JOLLY\n\n\t\tCOMPLIMENTI!!!"; 
		 return 0;
		 }
		 else
		 {
		 cout<<"\nMI SPAICE NON HAI PRESO IL NUMERO JOLLY\n";    
		 cout<<"\nHAI L'ULTIMA POSSIBILITA'\nPROVA CON IL NUMERO SUPER STAR\n";
		 }
		 cout<<"\n\t\tINSERISCI IL NUMERO STAR--> ";
		 cin>>n;
		 if(n==super){
		   cout<<"\tHAI PRESO I NUMERO super star\n\n\t\tCOMPLIMENTI!!!"; 
		   
		 }
		 else
		 {
		     cout<<"\nSEI PROPRIO SFIGATO!!\n\n";
		     cout<<"\t\t@  @  @  @  @  @\n";
		     cout<<"\t\t ||    ||    ||\n";
		     cout<<"\t\t====  ====  ====\n";
		 
      
    
    }
    } 
   


return 0;
}
