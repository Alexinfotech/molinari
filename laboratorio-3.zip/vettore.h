#include <iostream>
#include <ctime>

using namespace std;

void carica(int* p, int dim);
void stampa(int* p, int dim);