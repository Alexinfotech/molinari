/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

{
    int mio_arrY[]=(23,43,45,13,65,89,78,56,12,36);
    int i=10;
    int resto=0;
for(i=10;i>0;i--)
{
    resto=i%2;
    
    if(resto==1)
    {
    
        cout<<endl;
    }
}
    return 0;
}
