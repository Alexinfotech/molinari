/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    char ch;//carattere
    int N;//intero
   if(N>=10 && N<=20) // controllo numeri 
  if( ch>='a' && ch<='z' || ch>='A' && ch<='Z') //controllo lettre
   {
       
       else
        {
            printf("hai fatto la scelta sbagliata");
        }
    

    return 0;
}
