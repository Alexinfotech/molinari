/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    class A{
        pubblic:
        A(){x=5};
        A(int b){cout<<b;};
        A(int c, int d){cout<<c<<d;};
        int x;
    }
 /*********************************************************/   
    A* a=n NULL;
    
    a = new A;// primo costruttore
    a = new A (5);//secondo costruttore
    a = new A (4,8);//terzo costruttore
    //alloca uno spazzio di meromria in base al tipo previsto dalla classe in oggetto
    //poi passa l'idirizzo di partenza in qiuesto caso alloca spazio per i vari costruttori
    }
    A* a = NULL;
    a=new A;
    (*a).x=15;
    //alternativa
    a->x=18;
    
    
}
