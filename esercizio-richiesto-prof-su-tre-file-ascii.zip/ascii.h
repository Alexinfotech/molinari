#include<stdio.h>
#include<stdlib.h>

void start_tab_ascii();
void ins_num(int n, char temp);
void ins_asci(char ch);
void stamp_num_ascii_ins(int n,char ch);
void continue_ascii(int n,char ch,char ch2);