
#include "ascii.h"

int main()
{
    char ch ;
    char ch2;
    int n ;
    char temp;//invio preso come carattere
    
start_tab_ascii();
ins_num(n,temp);
ins_asci(ch);
stamp_num_ascii_ins(n,ch);
continue_ascii(n,ch,ch2);         

return 0;
}
