#include <iostream>
using namespace std;

#define N 11

int main(){
	int a[N];

	for (int i = 0; i<N; i++){		
		a[i]=i*5;
		cout<<a[i]<<" ";
	}
   return 0;
}
