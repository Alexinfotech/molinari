classe Prova{
    public:
    int a;
    
};