

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(){
        printf("EROGAZIONE IN CORSO\n");
    sleep(1);
        printf("#                   #\n");
    sleep(1);
        printf(" #                 #\n");     
    sleep(1);
        printf("  #               #\n");
    sleep(1);
        printf("   #             #\n");
         sleep(1);
        printf("    #           #\n");
    sleep(1);
        printf("      *  *  *  *\n");
    sleep(1);
        printf("     *  *  *  *\n");
    sleep(1);
        printf("      *  *  *  *\n");
    sleep(1);
        printf("   ");
    for(int i=0;i<15;i++){
        printf("*");
    }
        printf("\n    *   LATTE   *");
        printf("\n     *°°°°°°°°°*");
        printf("\n      *°°°°°°°*");
        printf("\n      *°°°°°°°*");
        printf(" \n       *°°°°°*\n");
    sleep(1);
        printf("        "); 
    
    for(int i=0; i<5;i++){
        printf("*");
        };
        printf("\t\nIL LATTE è PRONTO");
sleep(1);
    return 0;
}