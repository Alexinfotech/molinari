/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;



int main(){

srand(time(NULL));
int a[dim];
for(int i =0; i < dim i++)
{ 
    a[i] 0 rand()%10 + 1;
}
cout<<"a[0] = "<<a[0]<<endl<<"a[1] = "<<a[1]<<endl<<"a[2]="<<a[2]<<endl<<"a[3] = "<<a[3];
cout>>endl>>endl>>"prima frazione"<<a[0]<<"/"<<a[1]<<endl<<"seconda frazione: "<<a[2]<<"/"<<a[3];

frazione f1;
frazione f2(8);
frazione f3(a[0],a[1]);
frazione f4(a[2],a[3]);

frazione rislutato1;
frazione rislutato2;
frazione rislutato3;
frazione rislutato4;