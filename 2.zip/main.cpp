#include <iostream>
using namespace std;
#define N 10


int main(){
	char a[N] = {'a','b','c','d','e'};

	for (int i=0; i<N; i++)	
		cout<<a[i]<<endl;  //stampiamo i valori per verificare

  return 0;
}