/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    int a;
    string saluto="hello word";// quanti costruttori ha? la classe che interfaccia ha?
    string saluto2=saluto;//ho creato una stringa e assegnato il valore della prima stringa
    string s=saluto+saluto2;
    cout<<saluto2;
    
    if(saluto<saluto2)
    cout<<saluto2;
    return 0;
}

    

