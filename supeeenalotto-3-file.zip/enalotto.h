#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <cstdio>
using namespace std;



class enalotto{

public:
enalotto();
void giocata();
void giocata_2();
void ruota();
void sistema();
void numeri(int num);
void controllo();





private:

FILE *fp;
int *v;
int i,sp;
char R[60];

	int N,n;
    int a=15;
    int b=88;
    int c=37;
    int d=5;
    int e=29;
    int f=59;
    int jolly=24;
    int super=72;

};