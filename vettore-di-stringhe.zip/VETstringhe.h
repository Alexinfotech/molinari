
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



#define MAXNOMI 50//fino a 50 nomi
#define LUNNOME 40//ogni nome fino a 40 caartteri


