/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main(){
    
    cout << "Hello World \t" << "seconda \t" << "terza \t" << "a capo\n" << "ciao\n" << "ciao\a";   // la t sereve per scheda orizzontale// count = stampa // \n a capo // a suono
  
    return 0;
}

#include <iostream>
using namespace std;

int main() {
  int x = 5;
  int y = 6;
  int z = 2;
  int sum = x + y + z;
  cout << sum;
  return 0;
}

