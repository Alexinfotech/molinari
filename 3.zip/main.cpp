/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <cstdlib>
using namespace std;
#define N 1

int main()
{char car;
  int i;
  int a;
  srand(car);
	for (i=0; i<N; i++){		
		a[i]=rand();
	}

 for(i = 48; i<=90; i++)
   {car=i;
    printf("\nIl carattere %c ha codice ASCII %4d",car,i);}

 return 0;
}