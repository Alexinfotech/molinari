
#include <iostream>
 using namespace std;
int main()
{
    char c = 'K';
 
    int i = int(c);
 
   std::cout << i << std::endl;        // 75
 
    return 0;
}
 


  