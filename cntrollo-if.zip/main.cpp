/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    int numero=0;  cout << "numero" <<endl;
    cin >> numero;
    if (numero&2==0)
{cout << "il numero è pari!" <<endl;}
else
{cout << "il numero è dispari" <<endl;}
return 0;
}

 
